/** Automatically generated file. DO NOT MODIFY */
package unf.edu.jambaaddressbook;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}